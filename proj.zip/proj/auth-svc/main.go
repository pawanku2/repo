package main

import (
	"database/sql"
	"os"
    "golang.org/x/net/context"
	"fmt"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
    price "github.com/proj/auth-svc/rpc/book-price"
)

var db *sql.DB
var err error
func getBookPrice(res http.ResponseWriter, req *http.Request) {
     
           //if req.Method != "POST" {
            fmt.Printf("\n Hello getBookPrice");
             http.ServeFile(res, req, "price.html")
                  //http.Redirect(res, req, "price.html", 301)
               //  return
                //}
            
                  bookname := req.FormValue("bookname")
                  fmt.Printf("Bookname recived from html %v\n",bookname);
                   p, err := priceRPC.GetPrice(context.Background(), &price.Payload{Value: bookname})
                   fmt.Printf("Value of P %v \n",p)
                    if err != nil {
                             fmt.Println(err)
                              http.Redirect(res, req, "/price", 301)
                               return
                            }
                        
                              res.Write([]byte(bookname + "Price is :" + p.GetValue()))
                          
                            }

func signupPage(res http.ResponseWriter, req *http.Request) {

	// Serve signup.html to get requests to /signup
	if req.Method != "POST" {
		http.ServeFile(res, req, "signup.html")
		return
	}

	username := req.FormValue("username")
	password := req.FormValue("password")

	var user string

	err := db.QueryRow("SELECT username FROM users WHERE username=?", username).Scan(&user)

	switch {
	// Username is available
	case err == sql.ErrNoRows:
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
		if err != nil {
			http.Error(res, "Server error, unable to create your account.", 500)
			return
		}

		_, err = db.Exec("INSERT INTO users(username, password) VALUES(?, ?)", username, hashedPassword)
		if err != nil {
			http.Error(res, "Server error, unable to create your account.", 500)
			return
		}

		res.Write([]byte("User created!"))
		return
	case err != nil:
		http.Error(res, "Server error, unable to create your account.", 500)
		return
	default:
		http.Redirect(res, req, "/", 301)
	}
}

func loginPage(res http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		http.ServeFile(res, req, "login.html")
		return
	}

	username := req.FormValue("username")
	password := req.FormValue("password")

	var databaseUsername string
	var databasePassword string

	err := db.QueryRow("SELECT username, password FROM users WHERE username=?", username).Scan(&databaseUsername, &databasePassword)

	if err != nil {
		http.Redirect(res, req, "/login", 301)
		return
	}

	err = bcrypt.CompareHashAndPassword([]byte(databasePassword), []byte(password))
	if err != nil {
		http.Redirect(res, req, "/login", 301)
		return
	}

	res.Write([]byte("Hello" + databaseUsername))

}

func homePage(res http.ResponseWriter, req *http.Request) {
	http.ServeFile(res, req, "index.html")
}

func main() {
	db, err = sql.Open("mysql", os.Getenv("DATABASE_URL"))
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		panic(err.Error())
	}

	setupRPCClientConnection()
    fmt.Printf("Hello Main");
	http.HandleFunc("/books", getBooks)
	http.HandleFunc("/price", getBookPrice)
	//http.HandleFunc("/get_price", getBookPrice)
	http.HandleFunc("/signup", signupPage)
	http.HandleFunc("/login", loginPage)
	http.HandleFunc("/", homePage)

	http.ListenAndServe(os.Getenv("PORT"), nil)
}
